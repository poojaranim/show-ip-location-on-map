This files only work on a public server, not on a local one.
You need mysqli Database and change on the top of each file your login data.
Import the ipadr.sql to your database.
Place the hole content of storeip.php on the top your your server file, p.e. index.html or index.php or any other file on your server.
Have fun and be sure, you have many visitors, most from USA and China.
Click on the icon and maybe a page will open.

Have fun and give me some response if you like it.

Klaus



